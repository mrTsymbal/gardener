<?php
/**
 * Plugin Name: Olins Theme Demo Install
 * Plugin URI: http://alethemes.com
 * Description: A plugin that offer the demo installation tool for Olins Theme.
 * Version: 1.0
 * Author: CRIK0VA / ALETHEMES.COM
 * Author URI: http://alethemes.com
 * License: GPL v2
 */

/**
 * Add Needed Post Types
 */

/**
 * Add Aletheme Options to Admin Navigation
 */
function olins_add_admin_menu() {
    add_theme_page( esc_html__('Demo Install', 'olins'), esc_html__('Demo Install', 'olins'), 'edit_posts', 'aletheme_theme_demos','ale_theme_demos');
}
add_action('admin_menu', 'olins_add_admin_menu', 1);